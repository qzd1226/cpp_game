Open the 'Character-Customizer-Gimp.xcf' file using Gimp or
Open the 'Character-Customizer-Gimp.psd' file using Photoshop

How to use (Gimp Version):
1. Open the .xcf file using gimp
2. On the lower right tab of GIMP you will see 'Layers'
3. Change the visibility of each line to reveal the sprites
4. Hit Export as .png file to make sure you transparent blocks

The tutorial video for recoloring: 
https://www.youtube.com/watch?v=VniciDO1Syc&t=9s&ab_channel=HaviAverillaXavierDev

Download Gimp here:
https://www.gimp.org/downloads/